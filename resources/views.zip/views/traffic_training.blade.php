<x-app-layout>
    @section('title')
        <span class="">Traffic Training</span>
    @endsection
    <div class="max-w-3xl mx-auto p-4">
        <div class="aspect-video">
            <iframe src="https://player.vimeo.com/video/913010007" frameborder="0"
                allow="autoplay; fullscreen; picture-in-picture" allowfullscreen
                class="w-full h-full rounded-lg shadow-md bg-white" title="Solo Ads Training"></iframe>
        </div>
    </div>

</x-app-layout>
