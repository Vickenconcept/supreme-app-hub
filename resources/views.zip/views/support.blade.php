<x-app-layout>
<div class="container mx-auto py-8">
    <h1 class="text-2xl font-bold mb-4">Support</h1>
    <!-- Add your content here -->
</div>
</x-app-layout>